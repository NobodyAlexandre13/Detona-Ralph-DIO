const estado = {
    view: {
        squard: document.querySelectorAll(".square"),
        enemy: document.querySelector(".enemy"),
        tempo: document.querySelector("#tempo"),
        pontua: document.querySelector("#pontua")
    },
    values: {
        hitposition: 0,
        resultado: 0,
        tempoCorrente: 60
    },
    action: {
        timerId: setInterval(aleatorioSquare, 1000),
        tempoDown: setInterval(countDonw, 1000),
    }
}

function countDonw(){
    estado.values.tempoCorrente--;
    estado.view.tempo.textContent = estado.values.tempoCorrente;
    
    if(estado.values.tempoCorrente === 0){
        clearInterval(estado.action.tempoDown);
        clearInterval(estado.action.timerId);
        alert("Tempo terminou! \nA tua pontuação foi: "+estado.values.resultado);
    }
}
function playSom(nomeA){
    let audio = new Audio(`./src/audio/${nomeA}.m4a`)
    audio.volume = 0.2
    audio.play()
}

function aleatorioSquare(){
    estado.view.squard.forEach((square) => {
        square.classList.remove("enemy")
    })

    let NAliatorio = Math.floor(Math.random() *9);
    let QAleatorio = estado.view.squard[NAliatorio];
    QAleatorio.classList.add("enemy");
    estado.values.hitposition = QAleatorio.id;
}

/*function moveEnemy(){
    estado.values.timerId = setInterval(aleatorioSquare, 300)
}*/


function addListenerHitBox(){
    estado.view.squard.forEach((square) => {
        square.addEventListener("mousedown", ()=>{
            if(square.id === estado.values.hitposition){
                estado.values.resultado++;
                estado.view.pontua.textContent = estado.values.resultado;
                playSom("hit");
                estado.values.hitposition = null;
            }
        })
    });
}

function pricipal(){
    addListenerHitBox();
}

pricipal();